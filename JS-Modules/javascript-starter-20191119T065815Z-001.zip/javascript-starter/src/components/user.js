class User{
    constructor(){
        
    }
    getUser(){
        console.log('Init user');
        return '<p>User</p>'
    }
}

export default new User();