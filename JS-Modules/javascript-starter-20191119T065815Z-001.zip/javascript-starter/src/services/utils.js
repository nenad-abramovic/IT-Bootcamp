const countItems = (items) => {
    console.log('Number of items', items.length);
    return items.length;
}

export {
    countItems
}